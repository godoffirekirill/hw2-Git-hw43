

const Customers = () => {
    return (
        <div>
           Customers Component
        </div>
    );
};

export default Customers;