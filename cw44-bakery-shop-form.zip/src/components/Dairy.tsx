

const Dairy = () => {
    return (
        <div>
            Dairy Products
        </div>
    );
};

export default Dairy;