

const Orders = () => {
    return (
        <div>
            Orders Component
        </div>
    );
};

export default Orders;