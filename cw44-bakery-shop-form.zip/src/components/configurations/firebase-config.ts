// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
//import { getAnalytics } from "firebase/analytics";
import {getAuth} from 'firebase/auth';
import {getFirestore} from 'firebase/firestore'
// TODO: Add SDKs for Firebase products that you want to use



// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyB4c5EMNrQNbGhlpFnaBVf9594pSW1ZVxI",
    authDomain: "java-29-bakery-shop.firebaseapp.com",
    projectId: "java-29-bakery-shop",
    storageBucket: "java-29-bakery-shop.firebasestorage.app",
    messagingSenderId: "641083364981",
    appId: "1:641083364981:web:9309067e263057f9d54a3c"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
//const analytics = getAnalytics(app);
export const auth=getAuth(app);
export const db = getFirestore(app);