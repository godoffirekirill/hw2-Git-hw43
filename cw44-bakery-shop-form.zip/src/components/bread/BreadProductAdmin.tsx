import {ProductType} from "../../utils/types-bakery-shop.ts";
import {useAppSelector} from "../../app/hooks.ts";
import {DataGrid, GridActionsCellItem, GridColDef} from "@mui/x-data-grid";
import {Alert, Avatar, Box, Snackbar, Typography} from "@mui/material";
import appConfig from "../configurations/app-config.json";
import {useRef, useState} from "react";
import {removeProduct} from "../../firebase/fireBaseDbService.ts";
import {TrashBinIcon} from "../templates/CustomIcons.tsx";


const BreadProductAdmin = () => {
    const products: ProductType[] = useAppSelector(state => state.currProduct.products);
    const [open, setOpen] = useState(false);
    const alertMessage = useRef("Alert");
    //const filterdProducts = products.filter(products => products.category==="bread");
    const filterdProducts = products.filter(products => products);
    const columns: GridColDef[] = [
        { field: 'id', headerName: 'ID', flex: 0.3 },
        {field: 'title', headerName: 'Product name', flex: 1 },
        {field: 'category', headerName: 'Category', flex: 0.4 },
        {field: 'unit', headerName: 'Unit', flex: 0.4 },
        {field: 'cost', headerName: 'Cost(NIS)', flex: 0.4, editable:true },
        {field: 'img', headerName: 'Image', flex: 0.9, renderCell: (params)=>{
            const imagePath = params.value?`/images/${params.value}`:""
                return (
                    <Avatar
                        sx={{width: "60px", height: "60px", margin:"0 auto"}}
                        src={imagePath}
                        alt={params.row.title}
                    />
                )
            }, editable: true},
        {field:"actions", type:"actions", getActions: ({id}) =>
        [<GridActionsCellItem label={'remove'}
        icon={<TrashBinIcon/>}
        onClick={() => {
            removeProduct(id as string);
        }}
        />]
        },

        ]
    return (
      <Box sx={{width: "90vw", height: "90vw", margin:"0 auto"}}>
          <Typography component="h2" variant="h4" gutterBottom align="center">
              Bread Products
          </Typography>
          <DataGrid

              columns={columns}
              rows={filterdProducts}
              getRowHeight={()=>"auto"}
              disableRowSelectionOnClick
              processRowUpdate={(newRow, oldRow) => {
                  if(Math.abs(newRow.cost-oldRow.cost)/oldRow.cost >  appConfig.MAX_DISCOUNT)
                      throw new Error("You can't change product cost greater then 30%");
                  return newRow;
              }}
              onProcessRowUpdateError={(e) => {
                  alertMessage.current = e.message;
                  setOpen(true);

              }}
              />
          <Snackbar open={open} autoHideDuration={6000} onClose={() => {setOpen(false)}}>
              <Alert
                  severity="error"
                  variant="filled"
                  sx={{ width: '100%' }}
              >
                  {alertMessage.current}
              </Alert>
          </Snackbar>
      </Box>
    );
};

export default BreadProductAdmin;