

const Home = () => {
    return (
        <div>
           Home Component
        </div>
    );
};

export default Home;